<footer class="bg-gradient-to-r from-slate-950 via-blue-900 to-blue-950 border-t border-slate-800 text-center py-2 text-sm text-slate-300">
    � <?php echo e(date('Y')); ?> Dashboard
</footer>
<?php /**PATH C:\Users\Admin\LiveTrackCenterDetail\resources\views/layout/footer.blade.php ENDPATH**/ ?>