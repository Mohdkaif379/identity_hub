<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Center Details</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 10px; color: #111827; }
        h1 { font-size: 16px; margin: 0 0 10px 0; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #e5e7eb; padding: 4px 6px; text-align: left; vertical-align: top; }
        th { background: #f3f4f6; font-weight: 700; }
        .muted { color: #6b7280; }
    </style>
</head>
<body>
    <h1>Center Details</h1>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Alias</th>
                <th>ECN</th>
                <th>DOJ</th>
                <th>Center Name</th>
                <th>Name</th>
                <th>Projects Code</th>
                <th>CRM ID</th>
                <th>Email</th>
                <th>Gender</th>
                <th>KYC</th>
                <th>Created By (My Side)</th>
                <th>Created By</th>
                <th>Approved By</th>
                <th>IP Address</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($center->alias ?? '-'); ?></td>
                    <td><?php echo e($center->ecn ?? '-'); ?></td>
                    <td><?php echo e(optional($center->doj)->format('Y-m-d') ?? '-'); ?></td>
                    <td><?php echo e($center->centername ?? '-'); ?></td>
                    <td><?php echo e($center->name ?? '-'); ?></td>
                    <td><?php echo e($center->projectscode ?? '-'); ?></td>
                    <td><?php echo e($center->crmid ?? '-'); ?></td>
                    <td><?php echo e($center->email ?? '-'); ?></td>
                    <td><?php echo e($center->gender ?? '-'); ?></td>
                    <td><?php echo e($center->kyc_status ?? 'pending'); ?></td>
                    <td><?php echo e($center->created_by_my_side ?? '-'); ?></td>
                    <td><?php echo e($center->created_by ?? '-'); ?></td>
                    <td><?php echo e($center->approved_by ?? '-'); ?></td>
                    <td><?php echo e($center->ip_address ?? '-'); ?></td>
                    <td><?php echo e(optional($center->created_at)->format('Y-m-d H:i') ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="16" class="muted">No centers found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Bitmax\identity_hub\resources\views/center_details/pdf.blade.php ENDPATH**/ ?>