<header class="bg-gradient-to-r from-slate-950 via-blue-900 to-blue-950 border-b border-slate-800 px-6 py-3 flex justify-between items-center">
    <h1 class="text-xl font-semibold text-slate-100">Dashboard</h1>
    <div class="text-slate-200"><?php echo e(auth()->check() ? auth()->user()->name : 'Guest'); ?></div>
</header>
<?php /**PATH C:\Users\Admin\LiveTrackCenterDetail\resources\views/layout/header.blade.php ENDPATH**/ ?>