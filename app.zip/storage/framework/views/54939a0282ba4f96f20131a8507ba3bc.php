<aside class="w-64 bg-gradient-to-b from-slate-950 via-blue-900 to-blue-950 text-slate-100 h-full border-r border-slate-800">

  

    <div class="px-4 pt-6 pb-3">
        <div class="flex items-center gap-3">
            <div class="h-10 w-10 rounded-xl bg-blue-600 text-slate-100 flex items-center justify-center font-bold">
              GP
            </div>
            <div>
                <div class="text-sm font-bold text-slate-100">Global Projects</div>
                <div class="text-xs tracking-widest text-white">CONTROL CENTER</div>
            </div>
        </div>
    </div>

    <ul class="mt-2 space-y-2 px-4">
        <li>
            <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10">
                <i class="fas fa-home text-sm text-slate-100"></i>
                Dashboard
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('generate.link.index')); ?>" class="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-white/10">
                <i class="fas fa-link text-sm text-slate-200"></i>
                Links 
            </a>
        </li>
        
        <li>
            <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full text-left px-4 py-2 rounded-lg hover:bg-white/10 flex items-center gap-2">
                    <i class="fas fa-sign-out-alt text-sm text-slate-200"></i>
                    Log Out
                </button>
            </form>
        </li>
    </ul>

</aside>
<?php /**PATH C:\Users\Admin\LiveTrackCenterDetail\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>